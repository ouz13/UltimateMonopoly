package domain.cards;

public abstract class Card {
	

}
