package domain;

public class SpeedDie {
	
}
