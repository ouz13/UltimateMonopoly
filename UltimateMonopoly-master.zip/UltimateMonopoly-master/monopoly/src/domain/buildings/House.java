package domain.buildings;

public class House extends Building {

}
