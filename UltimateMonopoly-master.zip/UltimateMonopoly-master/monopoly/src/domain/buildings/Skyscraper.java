package domain.buildings;

import domain.square.PropertySquare;

public class Skyscraper extends Building {

}
