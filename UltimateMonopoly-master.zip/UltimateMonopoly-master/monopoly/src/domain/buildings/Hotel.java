package domain.buildings;

public class Hotel extends Building{

}
