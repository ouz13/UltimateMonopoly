package domain.buildings;

public abstract class Building {

}
