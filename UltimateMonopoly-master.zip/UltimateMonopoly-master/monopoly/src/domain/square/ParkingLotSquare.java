package domain.square;

public class ParkingLotSquare extends Square{
	int pool =0;
	
	public ParkingLotSquare(String n) {
		super.name = n;
		
	}
	
	
}
