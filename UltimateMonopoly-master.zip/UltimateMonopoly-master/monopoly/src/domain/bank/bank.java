package domain.bank;

public class bank {

}
