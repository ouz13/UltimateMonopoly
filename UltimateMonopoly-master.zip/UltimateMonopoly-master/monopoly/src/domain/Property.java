package domain;

import domain.player.*;
public class Property {

	String name;
	int price;
	int rent;
	Player owner;
}
