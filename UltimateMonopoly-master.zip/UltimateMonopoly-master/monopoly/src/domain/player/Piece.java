package domain.player;

import java.awt.Image;

public class Piece {

	String name;
	Image shape;
public Piece() {
	
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public Image getShape() {
	return shape;
}
public void setShape(Image shape) {
	this.shape = shape;
}


}


