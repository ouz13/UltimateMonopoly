package technical.IO;

public class io {

}
